-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j6a105.p.ssafy.io    Database: uts
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` int NOT NULL AUTO_INCREMENT,
  `user_nickname` varchar(20) NOT NULL,
  `user_wallet_address` varchar(100) NOT NULL,
  `user_profile_image` varchar(100) NOT NULL,
  `user_role` int NOT NULL DEFAULT '0' COMMENT '0:회원, 1:아티스트, 2: 관리자',
  `user_volume` double NOT NULL,
  `reg_dt` datetime NOT NULL,
  `mod_dt` datetime NOT NULL,
  `del_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`user_seq`),
  UNIQUE KEY `user_seq_UNIQUE` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'그린맨','0x7C2B78Ee13B3966673666c603541F17D0f08F62A','https://ipfs.infura.io/ipfs/QmThdWG3Ybu4tStSvfM9B1ViJS5ouhy5dpx4CZpx6frToA',1,0.0061,'2022-04-07 15:42:12','2022-04-08 01:07:36',NULL),(2,'우웨에엑','0xE38aFaA93a5a740D1AF87Abfc43d874C5Ab57934','https://ipfs.infura.io/ipfs/QmdQQ3uMMgPnVNTFqnyAEyZokUVb3v6LqKpP3jwqWDEtzi',1,0.0002,'2022-04-07 15:42:30','2022-04-08 01:10:08',NULL),(3,'JESSICA(패션)','0x7102B116A362d41D7D58bf669098C8Aeba76949a','https://cdn.pixabay.com/photo/2017/08/24/07/40/abstract-2675672_960_720.png',1,0.0021999999999999997,'2022-04-07 15:45:29','2022-04-07 20:41:02',NULL),(4,'The Bass','0x412ad07F6f735790fbE3126FA8B617c3b672e5E4','https://ipfs.infura.io/ipfs/QmRoZRVkBPDdnwtznWPdtBoMeRzfr19kY2AoziD4abCU1b',1,0.001,'2022-04-07 15:49:50','2022-04-07 22:49:45',NULL),(5,'user5','0x4458D530A8622FC8B23d699BB761fbE67C252CC3','https://cdn.pixabay.com/photo/2017/08/24/07/40/abstract-2675672_960_720.png',0,0,'2022-04-08 00:25:18','2022-04-08 00:25:18',NULL),(6,'user6','0x23D5ecFf8a5b9f9f5f57EAFE35268bC566BDda55','https://ipfs.infura.io/ipfs/QmauNKdi8xjbHk8d2LynqJrut5cascwEF2VcGV5793XRTw',0,0.0051,'2022-04-08 00:32:16','2022-04-08 01:10:08',NULL),(7,'user7','0x4e77ffB81aa1255E6F9E12A8EDAcfEE2e6b814cD','https://cdn.pixabay.com/photo/2017/08/24/07/40/abstract-2675672_960_720.png',0,0,'2022-04-08 00:52:04','2022-04-08 00:52:04',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 10:30:18
