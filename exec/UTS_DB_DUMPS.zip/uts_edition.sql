-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j6a105.p.ssafy.io    Database: uts
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edition`
--

DROP TABLE IF EXISTS `edition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edition` (
  `edition_seq` bigint NOT NULL AUTO_INCREMENT,
  `artist_seq` int NOT NULL,
  `edition_name` varchar(50) NOT NULL,
  `edition_image` varchar(100) NOT NULL,
  `edition_description` varchar(1000) NOT NULL,
  `edition_royalty` double NOT NULL,
  `reg_dt` datetime NOT NULL,
  PRIMARY KEY (`edition_seq`),
  UNIQUE KEY `edition_seq_UNIQUE` (`edition_seq`),
  KEY `artist_edition_fk_idx` (`artist_seq`),
  CONSTRAINT `artist_edition_fk` FOREIGN KEY (`artist_seq`) REFERENCES `artist` (`artist_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edition`
--

LOCK TABLES `edition` WRITE;
/*!40000 ALTER TABLE `edition` DISABLE KEYS */;
INSERT INTO `edition` VALUES (1,12,'#1.KOREA FASHION WEEK BENEFIT','https://ipfs.infura.io/ipfs/QmefqvfrfcMKocvMhYE2TzVuFAmRH4XL2eSGaF1kieWv1s','스타일리스트 JESSICA입니다.\n이번 서울 패션위크에 여러분을 초청합니다.\n이 NFT를 소유하시면 다음 혜택을 드립니다!\n\n1. 패션 위크 참여권 2회\n2. 1:1 스타일링 예약 우선권 3회',0,'2022-04-07 15:39:14'),(2,13,'Gangster Cat','https://ipfs.infura.io/ipfs/QmTL1WPxtKJs4sGhMrQMEnyQLq3SYr8siZ7wrzr92ZRCU5','두려워하라!!\n\n갱스터 캣은 야구 방망이를 매우 잘 휘두를 수 있기 때문있으니까...\n\n이 고양이와 함께라면 어디든 갈 수 있어!',5,'2022-04-07 15:39:14'),(3,9,'First Edition :)','https://ipfs.infura.io/ipfs/QmbiZ17BGFDJjYoj6NxR1ZreXHvGDuF8B3oeEA6GzXM6dd','제가  UTS에 처음으로 민팅하는 아주 의미있는 NFT입니다.\n이 에디션을 가지고 있는 분에게는 제 웹툰을 미리 볼 수 있는 네이버 쿠키를 한달에 10개씩 지급할 예정입니다!\n기한은 2022년동안!',0.1,'2022-04-07 15:39:14'),(4,14,'The Mighty Ether','https://ipfs.infura.io/ipfs/QmTzJLMdhWhMVhRMbLfL66eKtqnJEDH7J9itBP9XR6HSKY','The Mighty Ethereum 20th anniversary Limited Edition\n비탈릭 부테린이 정성껏 비빈 원조 손 맛',24,'2022-04-07 17:45:24'),(5,9,'그린맨 X UTS','https://ipfs.infura.io/ipfs/QmPqEQcXegVMTCUYSqm3swigWN1isU7LNojHoRhBCgvn1E','UTS와 그린맨의 콜라보!\n\n이 뱃지를 가지고 있는 분에게는 일년에 한번씩 그린맨이 그림을 그려드릴게요\n\n5년간 진행하는 프로젝트!!!!!',0.1,'2022-04-07 18:42:46');
/*!40000 ALTER TABLE `edition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 10:30:19
